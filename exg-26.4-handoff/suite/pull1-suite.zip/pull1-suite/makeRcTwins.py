"""Required-context corrections to the EFM conformance suite (EXG 3.1 ordering), for the 26.4 Pull 1 handoff.

For each valid variation that the EXG required context ordering turns into an error:
  - the original's expected result becomes the error now reported (EFM 6.5.21 entityCentralIndexKeyMissing: the
    selected required context does not hold the cover facts), with a sentence added to its description;
  - a corrected copy is added after it with the testcase's next free number, its data in its own folder named after
    the new id, expected valid (605-19 _006ng: expected 6.5.19 not found, by a header CIK no context matches).
Text is edited as bytes: CRLF and every other byte of the testcase file are kept.

Usage: python3 makeRcTwins.py <suite root (containing conf/)>
"""
import os, re, shutil, sys

ROOT = sys.argv[1]
CONF = os.path.join(ROOT, "conf")

def find(name):
    for d, _, fs in os.walk(CONF):
        if name in fs:
            return os.path.join(d, name)
    raise SystemExit("not found: " + name)

# ---- instance corrections ------------------------------------------------------------------------------------------

def ctxBlocks(t):
    return {m.group(2): m for m in re.finditer(r'(<(?:\w+:)?context id="([^"]+)">.*?</(?:\w+:)?context>)', t, re.S)}

def moveCoverFacts(t, fromCtx, toCtx):
    """A: the dei facts of the duration that held the cover facts move to the one-day context EXG selects."""
    n = 0
    def rep(m):
        nonlocal n
        a = m.group(0)
        if re.search(r'\bname="dei:', a) and re.search(r'\bcontextRef="%s"' % re.escape(fromCtx), a):
            n += 1
            return a.replace('contextRef="%s"' % fromCtx, 'contextRef="%s"' % toCtx)
        return a
    t = re.sub(r"<ix:(?:nonNumeric|nonFraction)\b[^>]*>", rep, t)
    assert n, "no dei facts moved"
    if not re.search(r'contextRef="%s"' % re.escape(fromCtx), t):  # now unused: drop it
        t = t.replace(ctxBlocks(t)[fromCtx].group(1), "")
    return t

def unwrapContextFacts(t, ctxIds):
    """B: facts in the given contexts are removed: each one's start tag and its balanced end tag are dropped, so its
    displayed text, and any fact nested in it, stay.  Then the contexts are removed."""
    for tag in ("nonNumeric", "nonFraction"):
        openPat = re.compile(r"<ix:%s\b([^>]*)>" % tag)
        pos = 0
        while True:
            m = openPat.search(t, pos)
            if not m:
                break
            c = re.search(r'\bcontextRef="([^"]+)"', m.group(1))
            if not (c and c.group(1) in ctxIds):
                pos = m.end(); continue
            depth, i = 1, m.end()
            while depth:
                o = openPat.search(t, i); cl = t.find("</ix:%s>" % tag, i)
                if o and o.start() < cl:
                    depth += 1; i = o.end()
                else:
                    depth -= 1; i = cl + len("</ix:%s>" % tag)
            closeStart = i - len("</ix:%s>" % tag)
            t = t[:m.start()] + t[m.end():closeStart] + t[i:]
            pos = m.start()
    blocks = ctxBlocks(t)
    for c in ctxIds:
        assert not re.search(r'contextRef="%s"' % re.escape(c), t), "still referenced: " + c
        t = t.replace(blocks[c].group(1), "")
    return t

def lastMonth(t, ctxIds):
    """C: transformation-sample contexts shortened to their last month, so they no longer outrank the cover context."""
    blocks = ctxBlocks(t)
    for c in ctxIds:
        b = blocks[c].group(1)
        end = re.search(r"<((?:\w+:)?)endDate>(\d{4})-(\d{2})-(\d{2})</", b)
        nb = re.sub(r"(<(?:\w+:)?startDate>)\d{4}-\d{2}-\d{2}(</)", r"\g<1>%s-%s-01\g<2>" % (end.group(2), end.group(3)), b)
        t = t.replace(b, nb)
    return t

# ---- the 17 variations -------------------------------------------------------------------------------------------

A = lambda t: moveCoverFacts(t, "From2008-01-01to2008-12-31", "From2008-12-312008-12-31")
CASES = [  # (testcase file, original id, instance correction or None, what the original now selects)
    ("22-forms-efm-testcase.xml", "_203gd", A, "step 5, the one-day context 2008-12-31"),
    ("22-forms-efm-testcase.xml", "_206gd", A, "step 5, the one-day context 2008-12-31"),
    ("22-forms-efm-testcase.xml", "_208gd", A, "step 5, the one-day context 2008-12-31"),
    ("22-forms-efm-testcase.xml", "_216gd", A, "step 5, the one-day context 2008-12-31"),
    ("605-56-prospectus-document-types-testcase.xml", "_240gd", A, "step 5, the one-day context 2008-12-31"),
    ("622-01-all-supported-locations-testcase.xml", "_038gd", A, "step 5, the one-day context 2008-12-31"),
    ("622-01-all-supported-locations-testcase.xml", "_055gd", A, "step 5, the one-day context 2008-12-31"),
    ("605-09-start-and-end-dates-distinct-testcase.xml", "_013gd", None, "step 5, a one-day context"),
    ("605-20-man-testcase.xml", "_013gd", "B", "step 4c, the 2023 annual context"),
    ("605-20-man-testcase.xml", "_036gd", "B", "step 4c, the 2023 annual context"),
    ("605-21-man-testcase.xml", "_007gd", "B", "step 4c, the 2023 annual context"),
    ("605-21-man-testcase.xml", "_022gd", "B", "step 4c, the 2023 annual context"),
    ("622-01-all-supported-locations-testcase.xml", "_040gd", "B", "step 4c, the 2023 annual context"),
    ("622-01-all-supported-locations-testcase.xml", "_057gd", "B", "step 4c, the 2023 annual context"),
    ("02-transform-efm-testcase.xml", "_010gd", lambda t: lastMonth(t, ["NFC1", "NFC2", "NFC3"]), "step 4d, the 2007 annual context NFC3"),
    ("02-transform-efm-testcase.xml", "_011gd", lambda t: lastMonth(t, ["NFC1", "NFC2", "NFC3"]), "step 4d, the 2007 annual context NFC3"),
    ("605-19-required-context-testcase.xml", "_006ng", "D", "step 4b, FY08_Form10KMember (a custom member of a standard axis no longer disqualifies)"),
]

def annualContexts(t):
    """B: the contexts of more than three quarters in an SBSEF quarterly or requested financial report."""
    out = []
    for cid, m in ctxBlocks(t).items():
        s = re.search(r"startDate>(\d{4}-\d{2}-\d{2})<", m.group(1)); e = re.search(r"endDate>(\d{4}-\d{2}-\d{2})<", m.group(1))
        if s and e:
            import datetime
            if (datetime.date.fromisoformat(e.group(1)) - datetime.date.fromisoformat(s.group(1))).days > 300:
                out.append(cid)
    return out

def variationText(tc, vid):
    m = re.search(r'([ \t]*<((?:conf:)?)variation id="%s">.*?</(?:conf:)?variation>\r?\n)' % re.escape(vid), tc, re.S)
    assert m, vid
    return m

def nextId(tc, suffix):
    nums = [(int(n), len(n)) for n in re.findall(r'variation id="_(\d+)[a-z]+"', tc)]
    width = max(w for _, w in nums)
    return "_%0*d%s" % (width, max(n for n, _ in nums) + 1, suffix)

done = []
for tcName, vid, fix, selected in CASES:
    path = find(tcName)
    tc = open(path, "rb").read().decode("utf-8")
    m = variationText(tc, vid)
    orig, p = m.group(1), m.group(2)
    nl = "\r\n" if "\r\n" in orig else "\n"
    data = re.search(r'<%sinstance readMeFirst="true">([^/<]+)/([^<]+)</%sinstance>' % (p, p), orig)
    folder, inst = data.group(1), data.group(2)
    if vid == "_006ng" and fix == "D":
        newId = nextId(tc, "ng")
    else:
        newId = nextId(tc, "gd")
    oldCore, newCore = vid[1:], newId[1:]
    newFolder = folder.replace(oldCore, newCore)
    assert newFolder != folder, (folder, oldCore)
    src, dst = os.path.join(os.path.dirname(path), folder), os.path.join(os.path.dirname(path), newFolder)
    os.makedirs(dst)
    for f in os.listdir(src):
        nf = f.replace(folder, newFolder)
        b = open(os.path.join(src, f), "rb").read()
        if f.lower().endswith((".htm", ".xml", ".xsd", ".html")):
            b = b.decode("utf-8").replace(folder, newFolder).encode("utf-8")
        open(os.path.join(dst, nf), "wb").write(b)
    newInst = os.path.join(dst, inst.replace(folder, newFolder))
    t = open(newInst, "rb").read().decode("utf-8")
    if fix == "B":
        t = unwrapContextFacts(t, annualContexts(t))
        how = "the annual facts and contexts are removed (EXG author, 2026-09-16: an SBSEF-FIN-QTR has no duration other than one to three quarters; annual statements belong in Exhibits I and J), so the quarter holding the cover facts is the required context"
    elif fix == "D":
        how = "the header CIK (parameter cik) matches no context's entity identifier, so step 1 of the ordering leaves no context and EFM 6.5.19 reports that no required context was found"
    elif fix is None:
        how = None
    else:
        t = fix(t)
        how = ("the cover facts are moved into the one-day context, which the ordering selects for a fund registration at step 5"
               if fix is A else
               "the transformation-sample contexts NFC1 to NFC3 are shortened to their last month, so the cover-fact context d is the longest at step 4c")
    open(newInst, "wb").write(t.encode("utf-8"))
    if how is None:   # no clean correction known: no copy, the original documents the change only
        shutil.rmtree(dst); newId = None
    # the original: its expected result becomes the error now reported
    note = (" Under the EDGAR XBRL Guide required context ordering (EXG 3.1) the required context is chosen at %s, which "
            "does not hold the cover facts, so they are reported missing (EFM 6.5.21)." % selected)
    if newId:
        note += " %s is the corrected instance." % newId
    newOrig = re.sub(r"(</%sdescription>)" % p, note.replace("\\", "\\\\") + r"\1", orig, count=1)
    assertXml = '<%sassert severity="err" num="60521" name="entityCentralIndexKeyMissing" frd="tbd"/>' % p
    if re.search(r"<%sresult expected=\"valid\"\s*/>" % p, newOrig):
        newOrig = re.sub(r"<%sresult expected=\"valid\"\s*/>" % p, "<%sresult>%s%s%s</%sresult>" % (p, nl, " " * 12 + assertXml, nl + " " * 8, p), newOrig)
    elif re.search(r"<%sresult expected=\"valid\">" % p, newOrig):
        newOrig = re.sub(r"<%sresult expected=\"valid\">" % p, "<%sresult>%s%s" % (p, nl, " " * 12 + assertXml), newOrig)
    else:  # _006ng: the 6.5.19 assert becomes 6.5.21
        newOrig = re.sub(r'<%sassert [^>]*num="60519"[^>]*/>' % p, assertXml, newOrig)
    new = ""
    if newId:
        new = orig.replace('id="%s"' % vid, 'id="%s"' % newId).replace(folder, newFolder)
        new = re.sub(r"(<%sname>)(.*?)(</%sname>)" % (p, p), lambda mm: mm.group(1) + "EXG required context, corrected: " + mm.group(2) + mm.group(3), new, count=1)
        new = re.sub(r"(<%sdescription>)(.*?)(</%sdescription>)" % (p, p),
                     lambda mm: mm.group(1) + "Corrected copy of %s: %s. " % (vid, how) + mm.group(2) + mm.group(3), new, count=1, flags=re.S)
        if fix == "D":
            new = re.sub(r'(&quot;submissionType&quot;)', r'&quot;cik&quot;: &quot;1111111111&quot;, \1', new, count=1)
    tc = tc.replace(orig, newOrig + new, 1)
    open(path, "wb").write(tc.encode("utf-8"))
    done.append((tcName, vid, newId, newFolder if newId else ""))
for d in done:
    print("%-48s %-7s -> %-7s %s" % d)
