# Pull 1 (required context): changes to the EFM conformance suite

These changes go with Pull 1. They apply to the published suite `efm-78-260914` (EDGAR 26.3), and are to be
applied before Pull 2's twins.

- `patches/`: five commits (`git format-patch`). Apply them with `git am` to a git checkout of the published
  suite, or read them as diffs.
- `files/`: every changed or added file in its final form, at the suite's own paths (`conf/...`). Line endings
  are as in the suite (CRLF).
- `makeRcTwins.py`: the script that made commit 5, from the 17 variations listed below.
- `suite-run.txt`: the run that checked the result.

## The five commits

1. **605-19 `_010gd`, `_011ng` (new).** A fee exhibit (424B2, EX-FILING FEES) whose context ends on the filing date
   is valid. One filed later is EFM 6.5.19. EXG 3.1.2 applies to fee exhibits.
2. **EXG 3.1.2: corrected `periodOfReport` in 29 variations.** Their header period matched no context in the
   instance, which the new header check reports.
   - 605-20 `_136`/`_141`/`_179`/`_184`gd
   - 605-21 `_130`/`_133`/`_136`/`_143`/`_520`gd
   - 605-24 `_124`/`_127`/`_142`/`_143`gd
   - 605-26 `_124`/`_127`gd
   - 605-40 `_129`/`_133`/`_135`gd
   - 605-46 `_131`/`_137`gd
   - 605-47 `_126`/`_131`gd
   - 605-48 `_112`/`_121`gd
   - 605-52 `_102`/`_106`gd
   - 605-53 `_100`/`_102`gd

   All of these go from 10-26-2018 to 12-31-2018. 624-rendering 03-unit-selection `_000gd` goes from 12-31-2015 to
   12-31-2008.
3. **605-54: six auditor-information variations** (`_170`–`_174`gd, `_180gd`). The instances' contexts are
   corrected to their stated fiscal year. Their periods of report are the auditor cutoff dates being tested, so
   they don't move.
4. **605-19 `_011ng`, `_012gd` (new).**
   - `_011ng` is now filed six business days after its contexts end, outside the filing-date window: 5 business
     or 6 calendar days before, to 1 business or 4 calendar days after. It remains EFM 6.5.19.
   - `_012gd` is filed two business days after, inside the window, and is valid.
5. **17 valid variations that the EXG ordering turns into errors.** The required context the ordering selects
   doesn't hold the cover facts, so EFM 6.5.21 and 6.5.20 report them missing. Each original now expects
   EFM 6.5.21 and says why. 16 get a corrected copy, numbered next in their testcase, with data in their own
   folder, expected valid:

| variations | selected by the ordering | correction in the copy |
|---|---|---|
| 22-forms `_203`/`_206`/`_208`/`_216`gd, 605-56 `_240gd`, 622-01 `_038`/`_055`gd (fund registrations) | step 5, the one-day context | cover facts moved into it: 22-forms `_302`–`_305`gd, 605-56 `_251gd`, 622-01 `_073`/`_074`gd |
| 605-20 `_013`/`_036`gd, 605-21 `_007`/`_022`gd, 622-01 `_040`/`_057`gd (SBSEF-FIN-QTR/REQ) | step 4c, the 2023 annual context | annual facts dropped; annual statements belong in Exhibits I and J: 605-20 `_405`/`_406`gd, 605-21 `_630`/`_631`gd, 622-01 `_075`/`_076`gd |
| 02-transform `_010`/`_011`gd (8-K) | step 4d, the 2007 sample context | sample contexts shortened to their last month: 02-transform `_218`/`_219`gd |
| 605-19 `_006ng` | step 4b, its FY context: a custom member of a standard axis no longer disqualifies | `_013ng`: a header CIK that no context matches, so no required context is found (EFM 6.5.19) |
| 605-09 `_013gd` | step 5, one of two one-day contexts twelve hours apart | none |

## Result

The whole suite with these changes was run on plugin `f17c06a`, the integration tree: Pull 1 plus the DQC removal and
the message references. On Arelle `24b6f2c1d` it gives 8,599 variations: 8,077 pass and 522 fail.

- Before the changes, the same code gave 8,582 variations: 8,042 pass and 540 fail.
- The 18 failures that go away are 605-19 `_011ng` and the 17 above. The 17 new variations pass.
- No other variation changes.
- The 16 corrected copies are also valid under 26.3. The 17 originals fail under 26.3, because their new
  expectation is the behaviour these changes introduce.

**What Pull 1 changes, measured separately on the suite before these changes.** Pull 1 alone (plugin `68541d2`)
against 26.3 (`4891c4c`) changes status in exactly these 17 variations. 178 others gain an EFM 6.5.19 message with
unchanged status: they already fail, or they match on their first assert. So the remaining failures are not Pull 1's
doing. On the suite before these changes, Pull 1 alone and the integration tree give the same status on all 8,582
variations. Codes differ only in 605-49 `_105gw` and `_118gw`, where Pull 1 alone also logs DQC.US.0006.14: Pull 1
keeps the hand-coded DQC rules, which the separate DQC-removal pull takes out.
